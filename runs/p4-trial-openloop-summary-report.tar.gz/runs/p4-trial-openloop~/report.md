# InferScale 单轮报告

策略：round_robin；负载：mixed；模式：open_loop

计划 120；发送 120；终态 {'not_sent': 0, 'succeeded': 120, 'rejected': 0, 'failed': 0, 'cancelled': 0}
窗口成功 117；drain 后成功 3。

| 指标 | 结果 |
|---|---|
| 窗口成功吞吐 req/s | 1.9500 |
| 成功 TTFT P50/P95 秒 | {'count': 120, 'p50': 0.09068203531205654, 'p95': 0.12890276266261935} |
| 成功 E2E P50/P95 秒 | {'count': 120, 'p50': 0.9034314742311835, 'p95': 4.358247483987361} |
| TPOT 估计秒（不等于逐 token ITL） | {'count': 120, 'p50': 0.015986557767869624, 'p95': 0.016602507040050684} |
| 输出 token 吞吐（未知时 null） | 257.18333333333334 |

自动排除理由：['uncontrolled_cache_state']。
缓存差分是 before→after-drain 的 cohort 观察，不是精确测量窗口差分。
亲和命中不等于后端缓存命中；chunk 间隔不等于 token 间隔。详情和分母见 summary.json。
